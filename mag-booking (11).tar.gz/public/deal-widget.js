const API = '/api';
let packages = [];
let dealInfo = null;
let existingBookings = [];
let rows = []; // {rowId, package_id, date_start, date_end, color}
let rowSeq = 1;
let colorPopupForRow = null;

function toast(message, type = 'warn') {
  const c = document.getElementById('toastContainer');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  c.appendChild(el);
  setTimeout(() => el.remove(), 6000);
}

async function api(path, opts) {
  const res = await fetch(API + path, { headers: { 'Content-Type': 'application/json' }, ...opts });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) { const err = new Error(data.error || 'Ошибка запроса'); err.data = data; throw err; }
  return data;
}

function pad(n) { return String(n).padStart(2, '0'); }
function isoOf(d) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
function ruOf(iso) { const [y, m, d] = iso.split('-'); return `${d}.${m}.${y}`; }

// ---------------- СТРОКИ ВЫБОРА ПАКЕТОВ ----------------
function addRow() {
  const today = isoOf(new Date());
  const used = rows.map(r => r.package_id);
  const freePkg = packages.find(p => !used.includes(p.id)) || packages[0];
  rows.push({
    rowId: rowSeq++,
    package_id: freePkg ? freePkg.id : (packages[0] && packages[0].id),
    date_start: today,
    date_end: today,
    color: COLOR_PALETTE[rows.length % COLOR_PALETTE.length]
  });
  renderRows();
}
function removeRow(rowId) {
  rows = rows.filter(r => r.rowId !== rowId);
  renderRows();
}

function renderRows() {
  const wrap = document.getElementById('pkgRows');
  if (!wrap) return;
  wrap.innerHTML = rows.map(r => `
    <div class="pkg-row" data-row="${r.rowId}">
      <select data-field="package_id">
        ${packages.map(p => `<option value="${p.id}" ${p.id === r.package_id ? 'selected' : ''}>${p.name}</option>`).join('')}
      </select>
      <input type="date" data-field="date_start" value="${r.date_start}">
      <input type="date" data-field="date_end" value="${r.date_end}">
      <div class="row-color" data-field="color" style="background:${r.color}"></div>
      <button type="button" class="row-remove" data-remove>✕</button>
    </div>
  `).join('');

  wrap.querySelectorAll('.pkg-row').forEach(rowEl => {
    const rowId = Number(rowEl.dataset.row);
    const row = rows.find(x => x.rowId === rowId);

    rowEl.querySelector('[data-field="package_id"]').addEventListener('change', (e) => { row.package_id = Number(e.target.value); });
    rowEl.querySelector('[data-field="date_start"]').addEventListener('change', (e) => { row.date_start = e.target.value; });
    rowEl.querySelector('[data-field="date_end"]').addEventListener('change', (e) => { row.date_end = e.target.value; });
    rowEl.querySelector('[data-remove]').addEventListener('click', () => removeRow(rowId));
    rowEl.querySelector('[data-field="color"]').addEventListener('click', (e) => openColorPopup(e.target, row));
  });
}

function openColorPopup(anchorEl, row) {
  const popup = document.getElementById('rowColorPopup');
  colorPopupForRow = row.rowId;
  popup.innerHTML = COLOR_PALETTE.map(c => `<div class="sw" style="background:${c}" data-color="${c}"></div>`).join('');
  const rect = anchorEl.getBoundingClientRect();
  popup.style.top = (window.scrollY + rect.bottom + 4) + 'px';
  popup.style.left = (window.scrollX + rect.left - 190) + 'px';
  popup.classList.add('open');
  popup.querySelectorAll('[data-color]').forEach(sw => {
    sw.onclick = () => {
      row.color = sw.dataset.color;
      popup.classList.remove('open');
      renderRows();
    };
  });
}
document.addEventListener('click', (e) => {
  const popup = document.getElementById('rowColorPopup');
  if (!popup.contains(e.target) && !e.target.classList.contains('row-color')) popup.classList.remove('open');
});

document.getElementById('btnCancel').onclick = () => {
  if (B24.available()) { try { BX24.closeApplication(); } catch (e) {} }
};

// ---------------- СОХРАНЕНИЕ ----------------
document.getElementById('btnSave').onclick = async () => {
  if (!rows.length) { toast('Добавьте хотя бы один пакет', 'warn'); return; }
  if (!dealInfo || !dealInfo.COMPANY_ID || !dealInfo.CONTACT_ID) {
    toast('В сделке не указаны Компания и/или Контакт — привяжите их в сделке перед бронированием', 'warn');
    return;
  }

  const items = rows.map(r => ({
    name: `Бронирование по сделке "${dealInfo.TITLE}"`,
    package_id: r.package_id,
    date_start: r.date_start,
    date_end: r.date_end,
    status: 'ЗАРЕЗЕРВИРОВАНО',
    company_id: dealInfo.COMPANY_ID,
    contact_id: dealInfo.CONTACT_ID,
    deal_id: dealInfo.ID,
    color: r.color
  }));

  try {
    const created = await api('/bookings/bulk', { method: 'POST', body: JSON.stringify({ items }) });

    // Формируем комментарий в сделку: каждая запись — новой строкой
    const lines = created.map(b => {
      const pkg = packages.find(p => p.id === b.package_id);
      const addr = pkg && Array.isArray(pkg.addresses) ? pkg.addresses.join('; ') : '';
      return `${pkg ? pkg.name : 'Пакет №' + b.package_id} — ${addr || 'адреса не заполнены'} — с ${ruOf(b.date_start)} по ${ruOf(b.date_end)}`;
    });
    const commentText = `Забронированы рекламные пакеты:\n${lines.join('\n')}`;

    try {
      await api('/deal-comment', { method: 'POST', body: JSON.stringify({ deal_id: dealInfo.ID, text: commentText }) });
    } catch (e) {
      console.warn('Не удалось добавить комментарий в сделку:', e.message);
    }

    toast('Бронирование сохранено', 'ok');
    setTimeout(() => { if (B24.available()) { try { BX24.closeApplication(); } catch (e) {} } }, 900);
  } catch (e) {
    toast(e.message, 'warn');
  }
};

// ---------------- ИНИЦИАЛИЗАЦИЯ ----------------
async function main() {
  packages = await api('/packages');
  const root = document.getElementById('root');

  // Контекст сделки приходит в URL после редиректа через шлюз VibeCode,
  // а не через BX24.placement.info() (SDK не видит его в этой схеме).
  const params = new URLSearchParams(window.location.search);
  const placement = params.get('placement') || '';
  let placementOptions = {};
  try { placementOptions = JSON.parse(params.get('placement_options') || '{}'); } catch (e) {}
  const dealId = placementOptions.ID;

  if (!placement.startsWith('CRM_DEAL_DETAIL') || !dealId) {
    root.innerHTML = '<p style="color:#d9534f;">Виджет должен открываться из карточки сделки Битрикс24.</p>';
    return;
  }

  // Проверка прав доступа — пользователь определяется сервером по заголовкам шлюза,
  // подделать его из браузера нельзя.
  const me = await api('/whoami').catch(() => ({ id: null, isAdmin: false }));
  let settings = { allowedUserIds: [] };
  try { settings = await api('/settings'); } catch (e) {}
  const restricted = settings.allowedUserIds && settings.allowedUserIds.length > 0;
  const allowed = !restricted || me.isAdmin || (me.id && settings.allowedUserIds.map(String).includes(String(me.id)));
  if (!allowed) {
    root.innerHTML = '<p style="color:#d9534f;">У вас нет прав на создание бронирований. Обратитесь к администратору портала.</p>';
    return;
  }

  // BX24 всё ещё нужен для чтения данных сделки и закрытия окна —
  // это работает независимо от placement.info().
  await new Promise((resolve) => B24.init(resolve));

  if (!B24.available()) {
    root.innerHTML = '<p style="color:#d9534f;">Виджет должен открываться внутри Битрикс24.</p>';
    return;
  }

  dealInfo = await B24.getDeal(dealId);
  existingBookings = await api(`/bookings/by-deal/${dealInfo.ID}`);

  const companyLink = dealInfo.COMPANY_ID ? `<a href="${B24.link('company', dealInfo.COMPANY_ID)}" target="_blank">Компания #${dealInfo.COMPANY_ID}</a>` : '<span style="color:#d9534f;">не указана в сделке</span>';
  const contactLink = dealInfo.CONTACT_ID ? `<a href="${B24.link('contact', dealInfo.CONTACT_ID)}" target="_blank">Контакт #${dealInfo.CONTACT_ID}</a>` : '<span style="color:#d9534f;">не указан в сделке</span>';
  const dealLink = `<a href="${B24.link('deal', dealInfo.ID)}" target="_blank">${dealInfo.TITLE}</a>`;

  root.innerHTML = `
    <h2>Бронирования пакетов по сделке</h2>
    <div class="deal-info">
      <div>Сделка: ${dealLink}</div>
      <div>Компания: ${companyLink}</div>
      <div>Контакт: ${contactLink}</div>
    </div>
    ${existingBookings.length ? `<div class="existing-note">По этой сделке уже есть ${existingBookings.length} бронирование(й). Можно добавить ещё.</div>` : ''}
    <div id="pkgRows"></div>
    <button class="btn small secondary" id="btnAddRow">+ Добавить пакет</button>
  `;
  document.getElementById('btnAddRow').onclick = addRow;

  addRow(); // сразу одна строка для удобства
  document.getElementById('bottomBar').style.display = 'flex';
}

main();
