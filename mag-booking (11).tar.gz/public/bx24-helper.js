// Обёртка над BX24.js: инициализация SDK (для BX24.callMethod и closeApplication),
// ссылки на портал. Личность и роль пользователя больше не определяются здесь —
// это делает сервер по заголовкам платформы VibeCode (см. /api/whoami),
// это надёжнее и не требует прав "Пользователи" у приложения.
// Поиск CRM-сущностей (компании/контакты/сделки/пользователи) идёт через
// серверный вебхук (/api/crm/*), а не напрямую из iframe.

const B24 = {
  ready: false,
  domain: null,

  init(cb) {
    if (typeof BX24 === 'undefined') {
      console.warn('BX24.js не загружен — приложение открыто вне Битрикс24.');
      cb && cb();
      return;
    }
    BX24.init(() => {
      B24.ready = true;
      try { B24.domain = BX24.getDomain ? BX24.getDomain() : null; } catch (e) {}
      cb && cb();
    });
  },

  available() {
    return typeof BX24 !== 'undefined' && B24.ready;
  },

  // Ссылка на карточку сущности в портале
  link(entityType, id) {
    if (!id) return null;
    if (!B24.domain) return null;
    const paths = { contact: 'crm/contact/details', company: 'crm/company/details', deal: 'crm/deal/details' };
    return `https://${B24.domain}/${paths[entityType]}/${id}/`;
  },

  callMethod(method, params) {
    return new Promise((resolve, reject) => {
      if (!B24.available()) return reject(new Error('BX24 недоступен'));
      BX24.callMethod(method, params, (result) => {
        if (result.error()) reject(result.error());
        else resolve(result.data());
      });
    });
  },

  // ---------- Поиск через серверный вебхук ----------
  async _searchViaServer(endpoint, query) {
    if (!query) return [];
    try {
      const res = await fetch(`/api/crm/${endpoint}?query=${encodeURIComponent(query)}`);
      if (!res.ok) return [];
      return await res.json();
    } catch (e) {
      return [];
    }
  },
  searchContacts(query) { return B24._searchViaServer('contacts', query); },
  searchCompanies(query) { return B24._searchViaServer('companies', query); },
  searchDeals(query) { return B24._searchViaServer('deals', query); },
  searchUsers(query) { return B24._searchViaServer('users', query); },

  getDeal(id) {
    return B24.callMethod('crm.deal.get', { id });
  }
};
