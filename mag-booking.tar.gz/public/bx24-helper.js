// Обёртка над BX24.js: инициализация, поиск CRM-сущностей, ссылки на портал.
// Работает как внутри Bitrix24 (iframe placement), так и (в ограниченном виде) вне его.

const B24 = {
  ready: false,
  domain: null,

  init(cb) {
    if (typeof BX24 === 'undefined') {
      console.warn('BX24.js не загружен — приложение открыто вне Битрикс24. CRM-поиск недоступен.');
      cb && cb();
      return;
    }
    BX24.init(() => {
      B24.ready = true;
      try { B24.domain = BX24.getDomain ? BX24.getDomain() : null; } catch (e) {}
      cb && cb();
    });
  },

  available() {
    return typeof BX24 !== 'undefined' && B24.ready;
  },

  // Ссылка на карточку сущности в портале
  link(entityType, id) {
    if (!id) return null;
    if (!B24.domain) return null;
    const paths = { contact: 'crm/contact/details', company: 'crm/company/details', deal: 'crm/deal/details' };
    return `https://${B24.domain}/${paths[entityType]}/${id}/`;
  },

  callMethod(method, params) {
    return new Promise((resolve, reject) => {
      if (!B24.available()) return reject(new Error('BX24 недоступен'));
      BX24.callMethod(method, params, (result) => {
        if (result.error()) reject(result.error());
        else resolve(result.data());
      });
    });
  },

  searchContacts(query) {
    if (!query) return Promise.resolve([]);
    return B24.callMethod('crm.contact.list', {
      filter: { '%NAME': query },
      select: ['ID', 'NAME', 'LAST_NAME', 'COMPANY_ID'],
      order: { ID: 'DESC' }
    }).then(list => list.map(c => ({
      id: c.ID,
      title: `${c.NAME || ''} ${c.LAST_NAME || ''}`.trim() || `Контакт #${c.ID}`,
      company_id: c.COMPANY_ID
    }))).catch(() => []);
  },

  searchCompanies(query) {
    if (!query) return Promise.resolve([]);
    return B24.callMethod('crm.company.list', {
      filter: { '%TITLE': query },
      select: ['ID', 'TITLE'],
      order: { ID: 'DESC' }
    }).then(list => list.map(c => ({ id: c.ID, title: c.TITLE || `Компания #${c.ID}` }))).catch(() => []);
  },

  searchDeals(query) {
    if (!query) return Promise.resolve([]);
    return B24.callMethod('crm.deal.list', {
      filter: { '%TITLE': query },
      select: ['ID', 'TITLE', 'COMPANY_ID', 'CONTACT_ID'],
      order: { ID: 'DESC' }
    }).then(list => list.map(d => ({ id: d.ID, title: d.TITLE || `Сделка #${d.ID}`, company_id: d.COMPANY_ID, contact_id: d.CONTACT_ID }))).catch(() => []);
  },

  getDeal(id) {
    return B24.callMethod('crm.deal.get', { id });
  }
};
