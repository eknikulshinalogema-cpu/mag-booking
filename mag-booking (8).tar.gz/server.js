const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const PACKAGES_FILE = path.join(__dirname, 'data', 'packages.json');
const BOOKINGS_FILE = path.join(__dirname, 'data', 'bookings.json');
const SETTINGS_FILE = path.join(__dirname, 'data', 'settings.json');

// ---------- Bitrix24 вебхук ----------
// Можно переопределить через переменную окружения BITRIX_WEBHOOK_URL, не трогая код.
const BITRIX_WEBHOOK_BASE = process.env.BITRIX_WEBHOOK_URL || 'https://b24-bm8cd9.bitrix24.ru/rest/13/6hc2fhizd0ms41gi/';

async function callBitrix(method, params = {}) {
  const url = `${BITRIX_WEBHOOK_BASE}${method}.json`;
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params)
  });
  const data = await response.json();
  if (data.error) {
    throw new Error(data.error_description || data.error);
  }
  return data.result;
}

// ---------- простое файловое хранилище (без внешних зависимостей) ----------
function readJSON(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) {
    return [];
  }
}
function writeJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
}

// ---------- утилиты дат (формат дд.мм.гггг хранится и отдаётся, внутри - ISO) ----------
function toISO(d) {
  // принимает дд.мм.гггг или гггг-мм-дд, возвращает гггг-мм-дд
  if (!d) return null;
  if (/^\d{4}-\d{2}-\d{2}$/.test(d)) return d;
  const m = d.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
  if (m) return `${m[3]}-${m[2]}-${m[1]}`;
  return d;
}
function toRU(d) {
  if (!d) return '';
  const m = d.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (m) return `${m[3]}.${m[2]}.${m[1]}`;
  return d;
}
function overlaps(aStart, aEnd, bStart, bEnd) {
  return aStart <= bEnd && bStart <= aEnd;
}

let nextId = (() => {
  const b = readJSON(BOOKINGS_FILE);
  return b.reduce((max, x) => Math.max(max, x.id || 0), 0) + 1;
})();

// ---------- НАСТРОЙКИ ДОСТУПА ----------
function readSettings() {
  try { return JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8')); }
  catch (e) { return { allowedUserIds: [] }; }
}
function writeSettings(s) { fs.writeFileSync(SETTINGS_FILE, JSON.stringify(s, null, 2), 'utf8'); }

// Пусто = доступ разрешён всем сотрудникам портала. Если список задан — только они + администраторы.
function checkAccess(req, res, next) {
  const settings = readSettings();
  if (!settings.allowedUserIds || !settings.allowedUserIds.length) return next();
  const userId = req.header('X-B24-User-Id');
  const isAdmin = req.header('X-B24-Is-Admin') === '1';
  if (isAdmin || (userId && settings.allowedUserIds.map(String).includes(String(userId)))) return next();
  return res.status(403).json({ error: 'У вас нет прав на бронирование пакетов. Обратитесь к администратору портала.' });
}
// Управление пакетами и списком доступа — только для администраторов портала.
function requireAdmin(req, res, next) {
  if (req.header('X-B24-Is-Admin') === '1') return next();
  return res.status(403).json({ error: 'Это действие доступно только администраторам портала.' });
}

app.get('/api/settings', (req, res) => res.json(readSettings()));
app.put('/api/settings', requireAdmin, (req, res) => {
  const allowedUserIds = Array.isArray(req.body.allowedUserIds) ? req.body.allowedUserIds.map(String) : [];
  const settings = { allowedUserIds };
  writeSettings(settings);
  res.json(settings);
});

// ---------- CRM-ПРОКСИ ЧЕРЕЗ ВЕБХУК (для поиска компаний/контактов/сделок/пользователей) ----------
app.get('/api/crm/companies', async (req, res) => {
  try {
    const q = (req.query.query || '').trim();
    const result = await callBitrix('crm.company.list', {
      filter: q ? { '%TITLE': q } : {},
      select: ['ID', 'TITLE'],
      order: { ID: 'DESC' }
    });
    res.json((result || []).slice(0, 20).map(c => ({ id: c.ID, title: c.TITLE || `Компания #${c.ID}` })));
  } catch (e) {
    res.status(502).json({ error: 'Ошибка запроса к Битрикс24: ' + e.message });
  }
});

app.get('/api/crm/contacts', async (req, res) => {
  try {
    const q = (req.query.query || '').trim();
    const result = await callBitrix('crm.contact.list', {
      filter: q ? { '%NAME': q } : {},
      select: ['ID', 'NAME', 'LAST_NAME', 'COMPANY_ID'],
      order: { ID: 'DESC' }
    });
    res.json((result || []).slice(0, 20).map(c => ({
      id: c.ID,
      title: `${c.NAME || ''} ${c.LAST_NAME || ''}`.trim() || `Контакт #${c.ID}`,
      company_id: c.COMPANY_ID
    })));
  } catch (e) {
    res.status(502).json({ error: 'Ошибка запроса к Битрикс24: ' + e.message });
  }
});

app.get('/api/crm/deals', async (req, res) => {
  try {
    const q = (req.query.query || '').trim();
    const result = await callBitrix('crm.deal.list', {
      filter: q ? { '%TITLE': q } : {},
      select: ['ID', 'TITLE', 'COMPANY_ID', 'CONTACT_ID'],
      order: { ID: 'DESC' }
    });
    res.json((result || []).slice(0, 20).map(d => ({
      id: d.ID, title: d.TITLE || `Сделка #${d.ID}`, company_id: d.COMPANY_ID, contact_id: d.CONTACT_ID
    })));
  } catch (e) {
    res.status(502).json({ error: 'Ошибка запроса к Битрикс24: ' + e.message });
  }
});

// Список/поиск пользователей портала — для страницы настроек прав доступа
app.get('/api/crm/users', async (req, res) => {
  try {
    const q = (req.query.query || '').trim().toLowerCase();
    const result = await callBitrix('user.get', { FILTER: { ACTIVE: true } });
    let list = result || [];
    if (q) {
      list = list.filter(u => `${u.NAME || ''} ${u.LAST_NAME || ''} ${u.EMAIL || ''}`.toLowerCase().includes(q));
    }
    res.json(list.map(u => ({
      id: u.ID,
      title: `${u.NAME || ''} ${u.LAST_NAME || ''}`.trim() || u.EMAIL || `Пользователь #${u.ID}`,
      email: u.EMAIL || ''
    })));
  } catch (e) {
    res.status(502).json({ error: 'Ошибка запроса к Битрикс24: ' + e.message });
  }
});

// ---------- ПАКЕТЫ ----------
app.get('/api/packages', (req, res) => {
  res.json(readJSON(PACKAGES_FILE));
});

// Создать новый пакет
app.post('/api/packages', requireAdmin, (req, res) => {
  const packages = readJSON(PACKAGES_FILE);
  const { name, addresses } = req.body;
  if (!name || !String(name).trim()) {
    return res.status(400).json({ error: 'Укажите название пакета' });
  }
  const id = packages.reduce((max, p) => Math.max(max, p.id), 0) + 1;
  const pkg = {
    id,
    name: String(name).trim(),
    addresses: Array.isArray(addresses) ? addresses.filter(a => a && a.trim()) : []
  };
  packages.push(pkg);
  writeJSON(PACKAGES_FILE, packages);
  res.json(pkg);
});

// Обновить пакет (название и/или список адресов)
app.put('/api/packages/:id', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const packages = readJSON(PACKAGES_FILE);
  const pkg = packages.find(p => p.id === id);
  if (!pkg) return res.status(404).json({ error: 'Пакет не найден' });
  if (req.body.name !== undefined) {
    if (!String(req.body.name).trim()) return res.status(400).json({ error: 'Название пакета не может быть пустым' });
    pkg.name = String(req.body.name).trim();
  }
  if (req.body.addresses !== undefined) {
    pkg.addresses = Array.isArray(req.body.addresses)
      ? req.body.addresses.filter(a => a && a.trim())
      : pkg.addresses;
  }
  writeJSON(PACKAGES_FILE, packages);
  res.json(pkg);
});

// Удалить пакет — запрещено, если по нему есть бронирования
app.delete('/api/packages/:id', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const packages = readJSON(PACKAGES_FILE);
  const pkg = packages.find(p => p.id === id);
  if (!pkg) return res.status(404).json({ error: 'Пакет не найден' });

  const bookings = readJSON(BOOKINGS_FILE);
  const related = bookings.filter(b => String(b.package_id) === String(id));
  if (related.length && req.query.force !== '1') {
    return res.status(409).json({
      error: `Нельзя удалить пакет "${pkg.name}": по нему есть ${related.length} бронирование(й). Сначала удалите или перенесите их.`,
      bookingsCount: related.length
    });
  }
  // при force=1 удаляем пакет вместе со связанными бронированиями
  const remainingPackages = packages.filter(p => p.id !== id);
  writeJSON(PACKAGES_FILE, remainingPackages);
  if (related.length) {
    writeJSON(BOOKINGS_FILE, bookings.filter(b => String(b.package_id) !== String(id)));
  }
  res.json({ ok: true });
});

// ---------- ЗАПИСИ (БРОНИРОВАНИЯ) ----------

// Список с фильтрами: package_id, status, date_from, date_to, company_id, contact_id
app.get('/api/bookings', (req, res) => {
  let bookings = readJSON(BOOKINGS_FILE);
  const { package_id, status, date_from, date_to, company_id, contact_id } = req.query;

  if (package_id) bookings = bookings.filter(b => String(b.package_id) === String(package_id));
  if (status && status !== 'ВСЕ') bookings = bookings.filter(b => b.status === status);
  if (company_id) bookings = bookings.filter(b => String(b.company_id) === String(company_id));
  if (contact_id) bookings = bookings.filter(b => String(b.contact_id) === String(contact_id));
  if (date_from && date_to) {
    const f = toISO(date_from), t = toISO(date_to);
    bookings = bookings.filter(b => overlaps(b.date_start, b.date_end, f, t));
  }
  res.json(bookings.map(formatOut));
});

function formatOut(b) {
  return { ...b, date_start_ru: toRU(b.date_start), date_end_ru: toRU(b.date_end) };
}

// Проверка пересечения (используется фронтом до сохранения, и повторно на сервере)
function findConflict(bookings, package_id, start, end, excludeId) {
  return bookings.find(b =>
    String(b.package_id) === String(package_id) &&
    b.id !== excludeId &&
    overlaps(b.date_start, b.date_end, start, end)
  );
}

app.post('/api/bookings/check-overlap', (req, res) => {
  const { package_id, date_start, date_end, exclude_id } = req.body;
  const bookings = readJSON(BOOKINGS_FILE);
  const start = toISO(date_start), end = toISO(date_end);
  const conflict = findConflict(bookings, package_id, start, end, exclude_id ? Number(exclude_id) : undefined);
  if (conflict) {
    return res.json({
      conflict: true,
      message: `Пакет №${package_id} занят с ${toRU(conflict.date_start)} по ${toRU(conflict.date_end)} (статус: ${conflict.status})`,
      booking: formatOut(conflict)
    });
  }
  res.json({ conflict: false });
});

app.post('/api/bookings', checkAccess, (req, res) => {
  const { name, package_id, date_start, date_end, status, contact_id, company_id, deal_id, color } = req.body;

  if (!package_id || !date_start || !date_end) {
    return res.status(400).json({ error: 'Не заполнены обязательные поля: пакет, дата начала, дата окончания' });
  }
  if (!contact_id || !company_id) {
    return res.status(400).json({ error: 'Необходимо указать Компанию и Контакт' });
  }

  const start = toISO(date_start), end = toISO(date_end);
  if (start > end) {
    return res.status(400).json({ error: 'Дата начала не может быть позже даты окончания' });
  }

  const bookings = readJSON(BOOKINGS_FILE);
  const conflict = findConflict(bookings, package_id, start, end);
  if (conflict) {
    return res.status(409).json({
      error: `Пакет №${package_id} занят с ${toRU(conflict.date_start)} по ${toRU(conflict.date_end)} (статус: ${conflict.status})`,
      conflict: formatOut(conflict)
    });
  }

  const booking = {
    id: nextId++,
    name: name || `Бронирование пакета №${package_id}`,
    package_id: Number(package_id),
    date_start: start,
    date_end: end,
    status: status === 'УТВЕРЖДЕНО' ? 'УТВЕРЖДЕНО' : 'ЗАРЕЗЕРВИРОВАНО',
    contact_id: contact_id || null,
    company_id: company_id || null,
    deal_id: deal_id || null,
    color: color || '#3498db',
    created_at: new Date().toISOString()
  };
  bookings.push(booking);
  writeJSON(BOOKINGS_FILE, bookings);
  res.json(formatOut(booking));
});

app.put('/api/bookings/:id', checkAccess, (req, res) => {
  const id = Number(req.params.id);
  const bookings = readJSON(BOOKINGS_FILE);
  const booking = bookings.find(b => b.id === id);
  if (!booking) return res.status(404).json({ error: 'Запись не найдена' });

  const patch = req.body;
  const newStart = patch.date_start ? toISO(patch.date_start) : booking.date_start;
  const newEnd = patch.date_end ? toISO(patch.date_end) : booking.date_end;
  const newPackage = patch.package_id !== undefined ? patch.package_id : booking.package_id;

  if (newStart > newEnd) {
    return res.status(400).json({ error: 'Дата начала не может быть позже даты окончания' });
  }

  const conflict = findConflict(bookings, newPackage, newStart, newEnd, id);
  if (conflict) {
    return res.status(409).json({
      error: `Пакет №${newPackage} занят с ${toRU(conflict.date_start)} по ${toRU(conflict.date_end)} (статус: ${conflict.status})`,
      conflict: formatOut(conflict)
    });
  }

  Object.assign(booking, {
    name: patch.name !== undefined ? patch.name : booking.name,
    package_id: Number(newPackage),
    date_start: newStart,
    date_end: newEnd,
    status: patch.status !== undefined ? patch.status : booking.status,
    contact_id: patch.contact_id !== undefined ? patch.contact_id : booking.contact_id,
    company_id: patch.company_id !== undefined ? patch.company_id : booking.company_id,
    deal_id: patch.deal_id !== undefined ? patch.deal_id : booking.deal_id,
    color: patch.color !== undefined ? patch.color : booking.color
  });

  writeJSON(BOOKINGS_FILE, bookings);
  res.json(formatOut(booking));
});

// Утвердить период: ЗАРЕЗЕРВИРОВАНО -> УТВЕРЖДЕНО
app.post('/api/bookings/:id/approve', checkAccess, (req, res) => {
  const id = Number(req.params.id);
  const bookings = readJSON(BOOKINGS_FILE);
  const booking = bookings.find(b => b.id === id);
  if (!booking) return res.status(404).json({ error: 'Запись не найдена' });
  booking.status = 'УТВЕРЖДЕНО';
  writeJSON(BOOKINGS_FILE, bookings);
  res.json(formatOut(booking));
});

app.delete('/api/bookings/:id', checkAccess, (req, res) => {
  const id = Number(req.params.id);
  let bookings = readJSON(BOOKINGS_FILE);
  const exists = bookings.some(b => b.id === id);
  if (!exists) return res.status(404).json({ error: 'Запись не найдена' });
  bookings = bookings.filter(b => b.id !== id);
  writeJSON(BOOKINGS_FILE, bookings);
  res.json({ ok: true });
});

// Найти сделке привязанное бронирование (для ссылки в карточке сделки)
app.get('/api/bookings/by-deal/:dealId', (req, res) => {
  const bookings = readJSON(BOOKINGS_FILE);
  const found = bookings.filter(b => String(b.deal_id) === String(req.params.dealId));
  res.json(found.map(formatOut));
});

// Свободные пакеты за период
app.get('/api/free-packages', (req, res) => {
  const { date_from, date_to } = req.query;
  if (!date_from || !date_to) return res.status(400).json({ error: 'Укажите период' });
  const start = toISO(date_from), end = toISO(date_to);
  const packages = readJSON(PACKAGES_FILE);
  const bookings = readJSON(BOOKINGS_FILE);

  const result = packages.map(p => {
    const conflicts = bookings.filter(b => String(b.package_id) === String(p.id) && overlaps(b.date_start, b.date_end, start, end));
    return {
      ...p,
      free: conflicts.length === 0,
      conflicts: conflicts.map(formatOut)
    };
  });
  res.json(result);
});

// Обработчик установки приложения (Bitrix24 шлёт сюда POST при установке/обновлении)
app.post('/install', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'install.html'));
});
app.get('/install', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'install.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`MAG Booking app listening on port ${PORT}`));
