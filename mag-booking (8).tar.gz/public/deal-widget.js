const API = '/api';
let packages = [];
let selectedColor = COLOR_PALETTE[0];
let dealInfo = null;
let existingBookings = [];

function toast(message, type = 'warn') {
  const c = document.getElementById('toastContainer');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  c.appendChild(el);
  setTimeout(() => el.remove(), 6000);
}

async function api(path, opts) {
  const headers = { 'Content-Type': 'application/json' };
  if (B24.currentUser && B24.currentUser.id) headers['X-B24-User-Id'] = String(B24.currentUser.id);
  if (B24.currentUser && B24.currentUser.isAdmin) headers['X-B24-Is-Admin'] = '1';
  const res = await fetch(API + path, { headers, ...opts });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) { const err = new Error(data.error || 'Ошибка запроса'); err.data = data; throw err; }
  return data;
}

function pad(n) { return String(n).padStart(2, '0'); }
function isoOf(d) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
function ruOf(iso) { const [y, m, d] = iso.split('-'); return `${d}.${m}.${y}`; }
const MONTH_NAMES = ['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
const DOW = ['Пн','Вт','Ср','Чт','Пт','Сб','Вс'];
function daysInMonth(y, m) { return new Date(y, m + 1, 0).getDate(); }

function buildMiniCal(container, initialIso, onSelect) {
  let view = initialIso ? new Date(initialIso) : new Date();
  let selected = initialIso;
  function render() {
    const y = view.getFullYear(), m = view.getMonth();
    const nd = daysInMonth(y, m);
    const firstDow = (new Date(y, m, 1).getDay() + 6) % 7;
    let html = `<div class="mini-cal-header"><button data-act="prev">←</button><span>${MONTH_NAMES[m]} ${y}</span><button data-act="next">→</button></div><div class="mini-cal-grid">`;
    DOW.forEach(d => html += `<div class="dow">${d}</div>`);
    for (let i = 0; i < firstDow; i++) html += `<div class="empty"></div>`;
    for (let d = 1; d <= nd; d++) {
      const iso = `${y}-${pad(m+1)}-${pad(d)}`;
      html += `<div class="day ${iso === selected ? 'selected' : ''}" data-iso="${iso}">${d}</div>`;
    }
    html += '</div>';
    container.innerHTML = html;
    container.querySelector('[data-act="prev"]').onclick = (e) => { e.stopPropagation(); view.setMonth(view.getMonth()-1); render(); };
    container.querySelector('[data-act="next"]').onclick = (e) => { e.stopPropagation(); view.setMonth(view.getMonth()+1); render(); };
    container.querySelectorAll('.day').forEach(el => {
      el.onclick = (e) => { e.stopPropagation(); selected = el.dataset.iso; onSelect(selected); container.classList.remove('open'); render(); };
    });
  }
  render();
  return { setSelected(iso) { selected = iso; if (iso) view = new Date(iso); render(); } };
}

let calStartCtl, calEndCtl;
function initMiniCalendars() {
  const calStartEl = document.getElementById('calStart');
  const calEndEl = document.getElementById('calEnd');
  calStartCtl = buildMiniCal(calStartEl, null, (iso) => { document.getElementById('fldStart').value = ruOf(iso); document.getElementById('fldStart').dataset.iso = iso; });
  calEndCtl = buildMiniCal(calEndEl, null, (iso) => { document.getElementById('fldEnd').value = ruOf(iso); document.getElementById('fldEnd').dataset.iso = iso; });
  document.getElementById('fldStart').addEventListener('click', (e) => { e.stopPropagation(); calEndEl.classList.remove('open'); calStartEl.classList.toggle('open'); });
  document.getElementById('fldEnd').addEventListener('click', (e) => { e.stopPropagation(); calStartEl.classList.remove('open'); calEndEl.classList.toggle('open'); });
  document.addEventListener('click', () => { calStartEl.classList.remove('open'); calEndEl.classList.remove('open'); });
}

function renderColorPalette() {
  const wrap = document.getElementById('colorPalette');
  wrap.innerHTML = COLOR_PALETTE.map(c => `<div class="color-swatch ${c === selectedColor ? 'selected' : ''}" style="background:${c}" data-color="${c}"></div>`).join('');
  wrap.querySelectorAll('.color-swatch').forEach(el => { el.onclick = () => { selectedColor = el.dataset.color; renderColorPalette(); }; });
}

async function loadPackagesAndFill() {
  packages = await api('/packages');
  document.getElementById('fldPackage').innerHTML = packages.map(p => `<option value="${p.id}">${p.name}</option>`).join('');
}

document.getElementById('btnCancel').onclick = () => {
  if (B24.available()) { try { BX24.closeApplication(); } catch (e) {} }
  document.getElementById('modalOverlay').classList.remove('open');
};

document.getElementById('btnSave').onclick = async () => {
  const payload = {
    name: document.getElementById('fldName').value,
    package_id: document.getElementById('fldPackage').value,
    date_start: document.getElementById('fldStart').dataset.iso,
    date_end: document.getElementById('fldEnd').dataset.iso,
    status: document.querySelector('input[name=status]:checked').value,
    company_id: dealInfo && dealInfo.COMPANY_ID || null,
    contact_id: dealInfo && dealInfo.CONTACT_ID || null,
    deal_id: dealInfo && dealInfo.ID || null,
    color: selectedColor
  };
  if (!payload.company_id || !payload.contact_id) {
    toast('В сделке не указаны Компания и/или Контакт — привяжите их в сделке перед бронированием', 'warn');
    return;
  }
  try {
    await api('/bookings', { method: 'POST', body: JSON.stringify(payload) });
    toast('Бронирование создано', 'ok');
    setTimeout(() => { if (B24.available()) { try { BX24.closeApplication(); } catch (e) {} } }, 800);
  } catch (e) {
    toast(e.message, 'warn');
  }
};

async function main() {
  await loadPackagesAndFill();
  renderColorPalette();

  const startIso = isoOf(new Date());
  document.getElementById('fldStart').value = ruOf(startIso); document.getElementById('fldStart').dataset.iso = startIso;
  document.getElementById('fldEnd').value = ruOf(startIso); document.getElementById('fldEnd').dataset.iso = startIso;
  initMiniCalendars();
  calStartCtl.setSelected(startIso);
  calEndCtl.setSelected(startIso);

  const root = document.getElementById('root');

  if (!B24.available()) {
    root.innerHTML = '<p style="color:#d9534f;">Виджет должен открываться внутри карточки сделки Битрикс24.</p>';
    document.getElementById('modalOverlay').classList.add('open');
    return;
  }

  const placementInfo = BX24.placement.info();
  const dealId = placementInfo && placementInfo.options && placementInfo.options.ID;

  // Проверка прав доступа к бронированию
  let settings = { allowedUserIds: [] };
  try { settings = await api('/settings'); } catch (e) {}
  const restricted = settings.allowedUserIds && settings.allowedUserIds.length > 0;
  const allowed = !restricted || B24.currentUser.isAdmin || (B24.currentUser.id && settings.allowedUserIds.map(String).includes(String(B24.currentUser.id)));
  if (!allowed) {
    root.innerHTML = '<p style="color:#d9534f;">У вас нет прав на создание бронирований. Обратитесь к администратору портала.</p>';
    return;
  }

  if (!dealId) {
    root.innerHTML = '<p style="color:#d9534f;">Не удалось определить сделку.</p>';
    return;
  }

  dealInfo = await B24.getDeal(dealId);
  document.getElementById('fldName').value = `Бронирование по сделке "${dealInfo.TITLE}"`;

  document.getElementById('companySelected').innerHTML = dealInfo.COMPANY_ID
    ? `<a href="${B24.link('company', dealInfo.COMPANY_ID)}" target="_blank">Компания #${dealInfo.COMPANY_ID}</a>`
    : '<span style="color:#d9534f;">не указана в сделке</span>';
  document.getElementById('contactSelected').innerHTML = dealInfo.CONTACT_ID
    ? `<a href="${B24.link('contact', dealInfo.CONTACT_ID)}" target="_blank">Контакт #${dealInfo.CONTACT_ID}</a>`
    : '<span style="color:#d9534f;">не указан в сделке</span>';
  document.getElementById('dealSelected').innerHTML = `<a href="${B24.link('deal', dealInfo.ID)}" target="_blank">${dealInfo.TITLE}</a>`;

  existingBookings = await api(`/bookings/by-deal/${dealInfo.ID}`);
  root.innerHTML = existingBookings.length
    ? `<p>По этой сделке уже есть ${existingBookings.length} бронирование(й). Можно создать ещё одно ниже.</p>`
    : '';

  document.getElementById('modalOverlay').classList.add('open');
}

B24.init(main);
