// Обёртка над BX24.js: инициализация, определение текущего пользователя,
// ссылки на портал. Поиск CRM-сущностей (компании/контакты/сделки/пользователи)
// идёт через серверный вебхук (/api/crm/*), а не напрямую из iframe —
// это надёжнее и не зависит от прав конкретного встроенного окна.

const B24 = {
  ready: false,
  domain: null,
  currentUser: { id: null, isAdmin: false, name: '' },

  init(cb) {
    if (typeof BX24 === 'undefined') {
      console.warn('BX24.js не загружен — приложение открыто вне Битрикс24.');
      cb && cb();
      return;
    }
    BX24.init(async () => {
      B24.ready = true;
      try { B24.domain = BX24.getDomain ? BX24.getDomain() : null; } catch (e) {}
      await B24.loadCurrentUser();
      cb && cb();
    });
  },

  available() {
    return typeof BX24 !== 'undefined' && B24.ready;
  },

  async loadCurrentUser() {
    if (!B24.available()) return;
    try {
      const me = await B24.callMethod('user.current', {});
      let isAdmin = false;
      try { isAdmin = await B24.callMethod('user.admin', {}); } catch (e) { isAdmin = false; }
      B24.currentUser = {
        id: me.ID,
        isAdmin: !!isAdmin,
        name: `${me.NAME || ''} ${me.LAST_NAME || ''}`.trim() || me.EMAIL || ('#' + me.ID)
      };
    } catch (e) {
      B24.currentUser = { id: null, isAdmin: false, name: '' };
    }
  },

  // Ссылка на карточку сущности в портале
  link(entityType, id) {
    if (!id) return null;
    if (!B24.domain) return null;
    const paths = { contact: 'crm/contact/details', company: 'crm/company/details', deal: 'crm/deal/details' };
    return `https://${B24.domain}/${paths[entityType]}/${id}/`;
  },

  callMethod(method, params) {
    return new Promise((resolve, reject) => {
      if (!B24.available()) return reject(new Error('BX24 недоступен'));
      BX24.callMethod(method, params, (result) => {
        if (result.error()) reject(result.error());
        else resolve(result.data());
      });
    });
  },

  // ---------- Поиск через серверный вебхук ----------
  async _searchViaServer(endpoint, query) {
    if (!query) return [];
    try {
      const res = await fetch(`/api/crm/${endpoint}?query=${encodeURIComponent(query)}`);
      if (!res.ok) return [];
      return await res.json();
    } catch (e) {
      return [];
    }
  },
  searchContacts(query) { return B24._searchViaServer('contacts', query); },
  searchCompanies(query) { return B24._searchViaServer('companies', query); },
  searchDeals(query) { return B24._searchViaServer('deals', query); },
  searchUsers(query) { return B24._searchViaServer('users', query); },

  getDeal(id) {
    return B24.callMethod('crm.deal.get', { id });
  }
};
