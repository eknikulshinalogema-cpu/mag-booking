const API = '/api';
let packages = [];
let bookings = [];
let activePackageFilter = null; // id пакета для фильтра в календаре
let rangeStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
let monthsSpan = 3;

let selectedCompany = null, selectedContact = null, selectedDeal = null;
let selectedColor = COLOR_PALETTE[0];
let editingId = null;

// ---------------- УТИЛИТЫ ----------------
function pad(n) { return String(n).padStart(2, '0'); }
function isoOf(d) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
function ruOf(iso) { const [y, m, d] = iso.split('-'); return `${d}.${m}.${y}`; }
function isoToRu(iso) { return ruOf(iso); }
const MONTH_NAMES = ['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
const DOW = ['Пн','Вт','Ср','Чт','Пт','Сб','Вс'];

function toast(message, type = 'warn') {
  const c = document.getElementById('toastContainer');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  c.appendChild(el);
  setTimeout(() => el.remove(), 6000);
}

async function api(path, opts) {
  const headers = { 'Content-Type': 'application/json' };
  if (B24.currentUser && B24.currentUser.id) headers['X-B24-User-Id'] = String(B24.currentUser.id);
  if (B24.currentUser && B24.currentUser.isAdmin) headers['X-B24-Is-Admin'] = '1';
  const res = await fetch(API + path, {
    headers,
    ...opts
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || 'Ошибка запроса');
    err.data = data;
    throw err;
  }
  return data;
}

// ---------------- ЗАГРУЗКА ДАННЫХ ----------------
async function loadPackages() {
  packages = await api('/packages');
  renderPackageList();
  fillPackageSelects();
}
async function loadBookings(filters = {}) {
  const qs = new URLSearchParams(filters).toString();
  bookings = await api('/bookings' + (qs ? '?' + qs : ''));
}

function fillPackageSelects() {
  const selModal = document.getElementById('fldPackage');
  const selFilter = document.getElementById('fPackage');
  selModal.innerHTML = packages.map(p => `<option value="${p.id}">${p.name}</option>`).join('');
  selFilter.innerHTML = '<option value="">Все пакеты</option>' + packages.map(p => `<option value="${p.id}">${p.name}</option>`).join('');
}

// ---------------- СПИСОК ПАКЕТОВ (левая панель) ----------------
function addressPreview(p) {
  const list = Array.isArray(p.addresses) ? p.addresses : [];
  return list.join(', ').slice(0, 60) || 'адреса не заполнены';
}

function renderPackageList() {
  document.getElementById('pkgCountTitle').textContent = `Пакеты (${packages.length})`;
  const wrap = document.getElementById('pkgItems');
  wrap.innerHTML = packages.map(p => `
    <div class="pkg-item-row">
      <div class="pkg-item ${activePackageFilter === p.id ? 'active' : ''}" data-id="${p.id}">
        ${p.name}
        <small>${addressPreview(p)}</small>
      </div>
      <div class="pkg-item-actions">
        <button data-edit="${p.id}" title="Редактировать">✎</button>
        <button data-del="${p.id}" title="Удалить">🗑</button>
      </div>
    </div>
  `).join('');
  wrap.querySelectorAll('.pkg-item').forEach(el => {
    el.addEventListener('click', () => {
      const id = Number(el.dataset.id);
      activePackageFilter = activePackageFilter === id ? null : id;
      document.getElementById('activePkgFilter').textContent = activePackageFilter ? `Фильтр: Пакет №${activePackageFilter}` : '';
      renderPackageList();
      renderGrid();
    });
  });
  wrap.querySelectorAll('[data-edit]').forEach(btn => {
    btn.addEventListener('click', (e) => { e.stopPropagation(); openPackageModal(Number(btn.dataset.edit)); });
  });
  wrap.querySelectorAll('[data-del]').forEach(btn => {
    btn.addEventListener('click', (e) => { e.stopPropagation(); deletePackage(Number(btn.dataset.del)); });
  });
}

// ---------------- УПРАВЛЕНИЕ ПАКЕТАМИ (создание / редактирование / удаление) ----------------
function renderAddressInputs(list) {
  const wrap = document.getElementById('pkgAddressList');
  wrap.innerHTML = (list.length ? list : ['']).map((addr, i) => `
    <div class="address-row" data-idx="${i}">
      <input type="text" value="${(addr || '').replace(/"/g, '&quot;')}" placeholder="Адрес рекламного места">
      <button type="button" data-remove="${i}">✕</button>
    </div>
  `).join('');
  wrap.querySelectorAll('[data-remove]').forEach(btn => {
    btn.onclick = () => {
      const rows = Array.from(wrap.querySelectorAll('.address-row'));
      if (rows.length <= 1) { rows[0].querySelector('input').value = ''; return; }
      btn.closest('.address-row').remove();
    };
  });
}
document.getElementById('btnAddAddressLine').onclick = () => {
  const wrap = document.getElementById('pkgAddressList');
  const div = document.createElement('div');
  div.className = 'address-row';
  div.innerHTML = `<input type="text" placeholder="Адрес рекламного места"><button type="button">✕</button>`;
  div.querySelector('button').onclick = () => {
    if (wrap.querySelectorAll('.address-row').length <= 1) { div.querySelector('input').value = ''; return; }
    div.remove();
  };
  wrap.appendChild(div);
};

function collectAddressInputs() {
  return Array.from(document.querySelectorAll('#pkgAddressList input'))
    .map(inp => inp.value.trim())
    .filter(Boolean);
}

function openPackageModal(pkgId) {
  const overlay = document.getElementById('pkgModalOverlay');
  document.getElementById('pkgId').value = pkgId || '';
  document.getElementById('btnPkgDelete').style.display = pkgId ? 'inline-block' : 'none';
  if (pkgId) {
    const p = packages.find(x => x.id === pkgId);
    document.getElementById('pkgModalTitle').textContent = `Редактирование: ${p.name}`;
    document.getElementById('pkgName').value = p.name;
    renderAddressInputs(Array.isArray(p.addresses) ? p.addresses : []);
  } else {
    document.getElementById('pkgModalTitle').textContent = 'Новый пакет';
    document.getElementById('pkgName').value = '';
    renderAddressInputs(['']);
  }
  overlay.classList.add('open');
}
document.getElementById('btnAddPackage').onclick = () => openPackageModal(null);
document.getElementById('btnPkgCancel').onclick = () => document.getElementById('pkgModalOverlay').classList.remove('open');

document.getElementById('btnPkgSave').onclick = async () => {
  const id = document.getElementById('pkgId').value;
  const name = document.getElementById('pkgName').value.trim();
  const addresses = collectAddressInputs();
  if (!name) { toast('Укажите название пакета', 'warn'); return; }
  try {
    if (id) await api(`/packages/${id}`, { method: 'PUT', body: JSON.stringify({ name, addresses }) });
    else await api('/packages', { method: 'POST', body: JSON.stringify({ name, addresses }) });
    toast('Пакет сохранён', 'ok');
    document.getElementById('pkgModalOverlay').classList.remove('open');
    await refreshAll();
  } catch (e) { toast(e.message, 'warn'); }
};

document.getElementById('btnPkgDelete').onclick = async () => {
  const id = document.getElementById('pkgId').value;
  if (!id) return;
  await deletePackage(Number(id));
};

async function deletePackage(id) {
  const pkg = packages.find(p => p.id === id);
  if (!pkg) return;
  if (!confirm(`Удалить пакет "${pkg.name}"?`)) return;
  try {
    await api(`/packages/${id}`, { method: 'DELETE' });
    toast('Пакет удалён', 'ok');
    if (activePackageFilter === id) activePackageFilter = null;
    document.getElementById('pkgModalOverlay').classList.remove('open');
    await refreshAll();
  } catch (e) {
    if (e.data && e.data.bookingsCount) {
      if (confirm(`${e.message}\n\nУдалить пакет вместе со всеми его бронированиями (${e.data.bookingsCount} шт.)? Это действие необратимо.`)) {
        await api(`/packages/${id}?force=1`, { method: 'DELETE' });
        toast('Пакет и связанные бронирования удалены', 'ok');
        if (activePackageFilter === id) activePackageFilter = null;
        document.getElementById('pkgModalOverlay').classList.remove('open');
        await refreshAll();
      }
    } else {
      toast(e.message, 'warn');
    }
  }
}

// ---------------- КАЛЕНДАРНАЯ СЕТКА ----------------
function daysInMonth(y, m) { return new Date(y, m + 1, 0).getDate(); }

function renderGrid() {
  const table = document.getElementById('gridTable');
  const months = [];
  for (let i = 0; i < monthsSpan; i++) {
    const d = new Date(rangeStart.getFullYear(), rangeStart.getMonth() + i, 1);
    months.push(d);
  }
  document.getElementById('rangeLabel').textContent =
    `${MONTH_NAMES[months[0].getMonth()]} ${months[0].getFullYear()} — ${MONTH_NAMES[months[months.length-1].getMonth()]} ${months[months.length-1].getFullYear()}`;

  let monthHeadRow = '<tr><th></th>';
  let dayHeadRow = '<tr><th class="pkg-name-head">Пакет</th>';
  months.forEach(m => {
    const nd = daysInMonth(m.getFullYear(), m.getMonth());
    monthHeadRow += `<th class="month-head" colspan="${nd}">${MONTH_NAMES[m.getMonth()]} ${m.getFullYear()}</th>`;
    for (let d = 1; d <= nd; d++) dayHeadRow += `<th class="day-head">${d}</th>`;
  });
  monthHeadRow += '</tr>'; dayHeadRow += '</tr>';

  const todayIso = isoOf(new Date());
  const shownPackages = activePackageFilter ? packages.filter(p => p.id === activePackageFilter) : packages;

  const rows = shownPackages.map(pkg => {
    const addrTitle = (Array.isArray(pkg.addresses) ? pkg.addresses.join(', ') : '').replace(/"/g,'&quot;');
    let row = `<tr><td class="pkg-name" data-pkg="${pkg.id}" title="${addrTitle}">${pkg.name}</td>`;
    months.forEach(m => {
      const nd = daysInMonth(m.getFullYear(), m.getMonth());
      for (let d = 1; d <= nd; d++) {
        const iso = `${m.getFullYear()}-${pad(m.getMonth()+1)}-${pad(d)}`;
        const b = bookings.find(bk => bk.package_id === pkg.id && iso >= bk.date_start && iso <= bk.date_end);
        const todayClass = iso === todayIso ? ' today' : '';
        if (b) {
          row += `<td class="${todayClass} cell-booking" style="background:${b.color}" data-booking="${b.id}" title="${b.name} (${b.status})"></td>`;
        } else {
          row += `<td class="${todayClass} cell-empty" data-pkg="${pkg.id}" data-date="${iso}"></td>`;
        }
      }
    });
    row += '</tr>';
    return row;
  }).join('');

  table.innerHTML = monthHeadRow + dayHeadRow + rows;

  table.querySelectorAll('.cell-booking').forEach(td => {
    td.addEventListener('click', () => openModal(Number(td.dataset.booking)));
  });
  table.querySelectorAll('.cell-empty').forEach(td => {
    td.addEventListener('click', () => openModal(null, { package_id: Number(td.dataset.pkg), date: td.dataset.date }));
  });
  table.querySelectorAll('.pkg-name').forEach(td => {
    td.addEventListener('click', () => {
      const id = Number(td.dataset.pkg);
      activePackageFilter = activePackageFilter === id ? null : id;
      renderPackageList(); renderGrid();
    });
  });
}

document.getElementById('prevRange').onclick = () => { rangeStart.setMonth(rangeStart.getMonth() - monthsSpan); renderGrid(); };
document.getElementById('nextRange').onclick = () => { rangeStart.setMonth(rangeStart.getMonth() + monthsSpan); renderGrid(); };
document.getElementById('btnApplyRange').onclick = () => {
  monthsSpan = Number(document.getElementById('monthsSpan').value);
  renderGrid();
  toast(`Показан период: ${document.getElementById('rangeLabel').textContent}`, 'ok');
};

// ---------------- МИНИ-КАЛЕНДАРЬ (попап выбора даты) ----------------
function buildMiniCal(container, initialIso, onSelect) {
  let view = initialIso ? new Date(initialIso) : new Date();
  let selected = initialIso;

  function render() {
    const y = view.getFullYear(), m = view.getMonth();
    const nd = daysInMonth(y, m);
    const firstDow = (new Date(y, m, 1).getDay() + 6) % 7; // понедельник=0
    let html = `<div class="mini-cal-header">
      <button data-act="prev">←</button>
      <span>${MONTH_NAMES[m]} ${y}</span>
      <button data-act="next">→</button>
    </div><div class="mini-cal-grid">`;
    DOW.forEach(d => html += `<div class="dow">${d}</div>`);
    for (let i = 0; i < firstDow; i++) html += `<div class="empty"></div>`;
    for (let d = 1; d <= nd; d++) {
      const iso = `${y}-${pad(m+1)}-${pad(d)}`;
      html += `<div class="day ${iso === selected ? 'selected' : ''}" data-iso="${iso}">${d}</div>`;
    }
    html += '</div>';
    container.innerHTML = html;

    container.querySelector('[data-act="prev"]').onclick = (e) => { e.stopPropagation(); view.setMonth(view.getMonth()-1); render(); };
    container.querySelector('[data-act="next"]').onclick = (e) => { e.stopPropagation(); view.setMonth(view.getMonth()+1); render(); };
    container.querySelectorAll('.day').forEach(el => {
      el.onclick = (e) => {
        e.stopPropagation();
        selected = el.dataset.iso;
        onSelect(selected);
        container.classList.remove('open');
        render();
      };
    });
  }
  render();
  return { setSelected(iso) { selected = iso; if (iso) view = new Date(iso); render(); } };
}

const calStartEl = document.getElementById('calStart');
const calEndEl = document.getElementById('calEnd');
let calStartCtl, calEndCtl;

function initMiniCalendars() {
  calStartCtl = buildMiniCal(calStartEl, null, (iso) => {
    document.getElementById('fldStart').value = ruOf(iso);
    document.getElementById('fldStart').dataset.iso = iso;
  });
  calEndCtl = buildMiniCal(calEndEl, null, (iso) => {
    document.getElementById('fldEnd').value = ruOf(iso);
    document.getElementById('fldEnd').dataset.iso = iso;
  });
}
document.getElementById('fldStart').addEventListener('click', (e) => { e.stopPropagation(); calEndEl.classList.remove('open'); calStartEl.classList.toggle('open'); });
document.getElementById('fldEnd').addEventListener('click', (e) => { e.stopPropagation(); calStartEl.classList.remove('open'); calEndEl.classList.toggle('open'); });
document.addEventListener('click', () => { calStartEl.classList.remove('open'); calEndEl.classList.remove('open'); });

// ---------------- ПАЛИТРА ЦВЕТОВ ----------------
function renderColorPalette() {
  const wrap = document.getElementById('colorPalette');
  wrap.innerHTML = COLOR_PALETTE.map(c => `<div class="color-swatch ${c === selectedColor ? 'selected' : ''}" style="background:${c}" data-color="${c}"></div>`).join('');
  wrap.querySelectorAll('.color-swatch').forEach(el => {
    el.onclick = () => { selectedColor = el.dataset.color; renderColorPalette(); };
  });
}

// ---------------- ПОИСК CRM (компания / контакт / сделка) ----------------
function setupSearch(inputId, resultsId, searchFn, onPick) {
  const input = document.getElementById(inputId);
  const results = document.getElementById(resultsId);
  let timer;
  input.addEventListener('input', () => {
    clearTimeout(timer);
    const q = input.value.trim();
    if (!q) { results.classList.remove('open'); return; }
    timer = setTimeout(async () => {
      const list = await searchFn(q);
      if (!list.length) { results.innerHTML = '<div style="color:#888;">Ничего не найдено</div>'; results.classList.add('open'); return; }
      results.innerHTML = list.map(item => `<div data-id="${item.id}">${item.title}</div>`).join('');
      results.classList.add('open');
      results.querySelectorAll('div[data-id]').forEach((el, i) => {
        el.onclick = () => { onPick(list[i]); results.classList.remove('open'); input.value = ''; };
      });
    }, 300);
  });
}

function renderSelectedEntity(elId, entityType, id, title) {
  const el = document.getElementById(elId);
  if (!id) { el.innerHTML = ''; return; }
  const link = B24.link(entityType, id);
  el.innerHTML = link
    ? `Выбрано: <a href="${link}" target="_blank">${title || ('#' + id)}</a> <a href="#" data-clear>(убрать)</a>`
    : `Выбрано: ${title || ('#' + id)} <a href="#" data-clear>(убрать)</a>`;
  el.querySelector('[data-clear]').onclick = (e) => {
    e.preventDefault();
    if (entityType === 'company') selectedCompany = null;
    if (entityType === 'contact') selectedContact = null;
    if (entityType === 'deal') selectedDeal = null;
    renderSelectedEntity(elId, entityType, null);
  };
}

setupSearch('fldCompanySearch', 'companyResults', B24.searchCompanies, (item) => {
  selectedCompany = item;
  renderSelectedEntity('companySelected', 'company', item.id, item.title);
});
setupSearch('fldContactSearch', 'contactResults', B24.searchContacts, (item) => {
  selectedContact = item;
  renderSelectedEntity('contactSelected', 'contact', item.id, item.title);
});
setupSearch('fldDealSearch', 'dealResults', B24.searchDeals, (item) => {
  selectedDeal = item;
  renderSelectedEntity('dealSelected', 'deal', item.id, item.title);
});

// ---------------- МОДАЛЬНОЕ ОКНО: СОЗДАНИЕ / РЕДАКТИРОВАНИЕ ----------------
function openModal(bookingId, presets = {}) {
  editingId = bookingId;
  const overlay = document.getElementById('modalOverlay');
  document.getElementById('modalTitle').textContent = bookingId ? 'Редактирование бронирования' : 'Новое бронирование';
  document.getElementById('btnDelete').style.display = bookingId ? 'inline-block' : 'none';

  selectedCompany = null; selectedContact = null; selectedDeal = null;
  selectedColor = COLOR_PALETTE[0];

  if (bookingId) {
    const b = bookings.find(x => x.id === bookingId);
    document.getElementById('bookingId').value = b.id;
    document.getElementById('fldName').value = b.name;
    document.getElementById('fldPackage').value = b.package_id;
    document.getElementById('fldStart').value = ruOf(b.date_start); document.getElementById('fldStart').dataset.iso = b.date_start;
    document.getElementById('fldEnd').value = ruOf(b.date_end); document.getElementById('fldEnd').dataset.iso = b.date_end;
    document.querySelector(`input[name=status][value="${b.status}"]`).checked = true;
    selectedColor = b.color;
    if (b.company_id) { selectedCompany = { id: b.company_id, title: b.company_title || ('#' + b.company_id) }; renderSelectedEntity('companySelected', 'company', b.company_id, selectedCompany.title); }
    if (b.contact_id) { selectedContact = { id: b.contact_id, title: b.contact_title || ('#' + b.contact_id) }; renderSelectedEntity('contactSelected', 'contact', b.contact_id, selectedContact.title); }
    if (b.deal_id) { selectedDeal = { id: b.deal_id, title: b.deal_title || ('#' + b.deal_id) }; renderSelectedEntity('dealSelected', 'deal', b.deal_id, selectedDeal.title); }
  } else {
    document.getElementById('bookingId').value = '';
    document.getElementById('fldName').value = '';
    document.getElementById('fldPackage').value = presets.package_id || (packages[0] && packages[0].id) || '';
    const startIso = presets.date || isoOf(new Date());
    const endIso = presets.dateEnd || startIso;
    document.getElementById('fldStart').value = ruOf(startIso); document.getElementById('fldStart').dataset.iso = startIso;
    document.getElementById('fldEnd').value = ruOf(endIso); document.getElementById('fldEnd').dataset.iso = endIso;
    document.querySelector('input[name=status][value="ЗАРЕЗЕРВИРОВАНО"]').checked = true;
    renderSelectedEntity('companySelected', 'company', null);
    renderSelectedEntity('contactSelected', 'contact', null);
    renderSelectedEntity('dealSelected', 'deal', null);
  }

  renderColorPalette();
  calStartCtl.setSelected(document.getElementById('fldStart').dataset.iso);
  calEndCtl.setSelected(document.getElementById('fldEnd').dataset.iso);
  overlay.classList.add('open');
}

function closeModal() { document.getElementById('modalOverlay').classList.remove('open'); }
document.getElementById('btnCancel').onclick = closeModal;
document.getElementById('btnNewBooking').onclick = () => openModal(null);

async function checkOverlapAndWarn() {
  const package_id = document.getElementById('fldPackage').value;
  const date_start = document.getElementById('fldStart').dataset.iso;
  const date_end = document.getElementById('fldEnd').dataset.iso;
  const exclude_id = document.getElementById('bookingId').value || undefined;
  const res = await api('/bookings/check-overlap', { method: 'POST', body: JSON.stringify({ package_id, date_start, date_end, exclude_id }) });
  if (res.conflict) {
    toast(res.message, res.booking.status === 'УТВЕРЖДЕНО' ? 'warn' : 'warn');
  }
  return res;
}

document.getElementById('fldStart').addEventListener('blur', () => setTimeout(checkOverlapAndWarn, 50));
document.getElementById('fldEnd').addEventListener('blur', () => setTimeout(checkOverlapAndWarn, 50));

function collectPayload() {
  return {
    name: document.getElementById('fldName').value,
    package_id: document.getElementById('fldPackage').value,
    date_start: document.getElementById('fldStart').dataset.iso,
    date_end: document.getElementById('fldEnd').dataset.iso,
    status: document.querySelector('input[name=status]:checked').value,
    company_id: selectedCompany ? selectedCompany.id : null,
    contact_id: selectedContact ? selectedContact.id : null,
    deal_id: selectedDeal ? selectedDeal.id : null,
    color: selectedColor
  };
}

document.getElementById('btnSave').onclick = async () => {
  const payload = collectPayload();
  if (!payload.company_id || !payload.contact_id) {
    toast('Необходимо указать Компанию и Контакт', 'warn'); return;
  }
  try {
    const id = document.getElementById('bookingId').value;
    if (id) await api(`/bookings/${id}`, { method: 'PUT', body: JSON.stringify(payload) });
    else await api('/bookings', { method: 'POST', body: JSON.stringify(payload) });
    toast('Бронирование сохранено', 'ok');
    closeModal();
    await refreshAll();
  } catch (e) {
    toast(e.message, 'warn');
  }
};

document.getElementById('btnApprovePeriod').onclick = async () => {
  const id = document.getElementById('bookingId').value;
  if (!id) {
    document.querySelector('input[name=status][value="УТВЕРЖДЕНО"]').checked = true;
    toast('Статус будет установлен как УТВЕРЖДЕНО после сохранения', 'ok');
    return;
  }
  try {
    await api(`/bookings/${id}/approve`, { method: 'POST' });
    toast('Период утверждён', 'ok');
    closeModal();
    await refreshAll();
  } catch (e) { toast(e.message, 'warn'); }
};

document.getElementById('btnDelete').onclick = async () => {
  const id = document.getElementById('bookingId').value;
  if (!id) return;
  if (!confirm('Удалить бронирование?')) return;
  await api(`/bookings/${id}`, { method: 'DELETE' });
  toast('Бронирование удалено', 'ok');
  closeModal();
  await refreshAll();
};

// ---------------- ВКЛАДКИ ----------------
const tabs = {
  calendar: document.getElementById('tabCalendar'),
  list: document.getElementById('tabList'),
  free: document.getElementById('tabFree'),
  settings: document.getElementById('tabSettings')
};
const views = {
  calendar: document.getElementById('viewCalendar'),
  list: document.getElementById('viewList'),
  free: document.getElementById('viewFree'),
  settings: document.getElementById('viewSettings')
};
function showTab(name) {
  Object.keys(views).forEach(k => { views[k].style.display = k === name ? '' : 'none'; tabs[k].classList.toggle('active', k === name); });
  if (name === 'list') renderListView();
  if (name === 'settings') renderSettingsView();
}
tabs.calendar.onclick = () => showTab('calendar');
tabs.list.onclick = () => showTab('list');
tabs.free.onclick = () => showTab('free');
tabs.settings.onclick = () => showTab('settings');

// ---------------- НАСТРОЙКИ ДОСТУПА ----------------
let allowedUserIds = [];
let settingsUserCache = [];

async function renderSettingsView(query) {
  const listWrap = document.getElementById('settingsUserList');
  const currentSettings = await api('/settings');
  allowedUserIds = (currentSettings.allowedUserIds || []).map(String);

  const users = await B24.searchUsers(query || '');
  settingsUserCache = users;

  if (!users.length) {
    listWrap.innerHTML = '<p style="color:#888;">Введите имя или почту сотрудника для поиска, либо оставьте поле пустым, чтобы увидеть первых сотрудников списком.</p>';
    return;
  }
  listWrap.innerHTML = users.map(u => `
    <label class="user-row">
      <input type="checkbox" data-uid="${u.id}" ${allowedUserIds.includes(String(u.id)) ? 'checked' : ''}>
      <span>${u.title}</span>
      <span class="user-email">${u.email || ''}</span>
    </label>
  `).join('');
}

let settingsSearchTimer;
document.getElementById('settingsUserSearch').addEventListener('input', (e) => {
  clearTimeout(settingsSearchTimer);
  settingsSearchTimer = setTimeout(() => renderSettingsView(e.target.value.trim()), 300);
});

document.getElementById('btnSaveSettings').onclick = async () => {
  const checked = Array.from(document.querySelectorAll('#settingsUserList input[type=checkbox]:checked')).map(c => c.dataset.uid);
  // объединяем отмеченные в текущем (отфильтрованном) списке с ранее сохранёнными, которые сейчас не показаны на экране
  const shownIds = settingsUserCache.map(u => String(u.id));
  const keptFromBefore = allowedUserIds.filter(id => !shownIds.includes(id));
  const newList = Array.from(new Set([...keptFromBefore, ...checked]));
  try {
    await api('/settings', { method: 'PUT', body: JSON.stringify({ allowedUserIds: newList }) });
    toast('Список доступа сохранён', 'ok');
    allowedUserIds = newList;
  } catch (e) {
    toast(e.message, 'warn');
  }
};

// ---------------- СПИСОК ЗАПИСЕЙ (таблица) ----------------
async function renderListView() {
  const filters = {
    package_id: document.getElementById('fPackage').value,
    status: document.getElementById('fStatus').value,
    date_from: document.getElementById('fDateFrom').value,
    date_to: document.getElementById('fDateTo').value
  };
  Object.keys(filters).forEach(k => !filters[k] && delete filters[k]);
  const list = await api('/bookings' + (Object.keys(filters).length ? '?' + new URLSearchParams(filters) : ''));
  const tbody = document.getElementById('listTbody');
  tbody.innerHTML = list.map(b => {
    const pkg = packages.find(p => p.id === b.package_id);
    const companyLink = B24.link('company', b.company_id);
    const contactLink = B24.link('contact', b.contact_id);
    const dealLink = B24.link('deal', b.deal_id);
    return `<tr>
      <td>${b.name}</td>
      <td>${pkg ? pkg.name : b.package_id}</td>
      <td>${b.date_start_ru}</td>
      <td>${b.date_end_ru}</td>
      <td><span class="status-badge ${b.status === 'УТВЕРЖДЕНО' ? 'appr' : 'res'}">${b.status}</span></td>
      <td>${b.company_id ? (companyLink ? `<a href="${companyLink}" target="_blank">#${b.company_id}</a>` : '#' + b.company_id) : '—'}</td>
      <td>${b.contact_id ? (contactLink ? `<a href="${contactLink}" target="_blank">#${b.contact_id}</a>` : '#' + b.contact_id) : '—'}</td>
      <td>${b.deal_id ? (dealLink ? `<a href="${dealLink}" target="_blank">#${b.deal_id}</a>` : '#' + b.deal_id) : '—'}</td>
      <td><button class="btn small secondary" data-edit="${b.id}">Открыть</button></td>
    </tr>`;
  }).join('');
  tbody.querySelectorAll('[data-edit]').forEach(btn => btn.onclick = () => openModal(Number(btn.dataset.edit)));
}
document.getElementById('btnApplyFilters').onclick = renderListView;
document.getElementById('btnResetFilters').onclick = () => {
  ['fPackage','fStatus','fDateFrom','fDateTo','fCompany','fContact'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('fStatus').value = 'ВСЕ';
  renderListView();
};

// ---------------- СВОБОДНЫЕ ПАКЕТЫ ЗА ПЕРИОД ----------------
document.getElementById('btnCheckFree').onclick = async () => {
  const from = document.getElementById('freeFrom').value;
  const to = document.getElementById('freeTo').value;
  if (!from || !to) { toast('Укажите период', 'warn'); return; }
  const list = await api(`/free-packages?date_from=${from}&date_to=${to}`);
  const tbody = document.getElementById('freeTbody');
  tbody.innerHTML = list.map(p => {
    const status = p.free
      ? `<span class="free-badge">СВОБОДЕН</span>`
      : p.conflicts.map(c => `<span class="busy-badge">ВНИМАНИЕ: занято с ${c.date_start_ru} по ${c.date_end_ru} (статус: ${c.status})</span>`).join('<br>');
    const addr = Array.isArray(p.addresses) ? p.addresses.join(', ') : (p.addresses || '');
    return `<tr>
      <td>${p.name}</td><td>${addr}</td><td>${status}</td>
      <td><button class="btn small" data-book="${p.id}">Перейти к бронированию</button></td>
    </tr>`;
  }).join('');
  tbody.querySelectorAll('[data-book]').forEach(btn => {
    btn.onclick = () => openModal(null, { package_id: Number(btn.dataset.book), date: from, dateEnd: to });
  });
};

// ---------------- ОБЩЕЕ ОБНОВЛЕНИЕ ----------------
async function refreshAll() {
  await loadPackages();
  await loadBookings();
  renderGrid();
}

// ---------------- ИНИЦИАЛИЗАЦИЯ ----------------
B24.init(async () => {
  // Показать имя текущего пользователя
  if (B24.currentUser.name) {
    document.getElementById('currentUserLabel').textContent = B24.currentUser.name + (B24.currentUser.isAdmin ? ' (администратор)' : '');
  }
  // Вкладка настроек доступа — только для администраторов портала
  if (B24.currentUser.isAdmin) {
    document.getElementById('tabSettings').style.display = '';
  }

  // Проверка прав на использование приложения
  let settings = { allowedUserIds: [] };
  try { settings = await api('/settings'); } catch (e) {}
  const restricted = settings.allowedUserIds && settings.allowedUserIds.length > 0;
  const allowed = !restricted || B24.currentUser.isAdmin || (B24.currentUser.id && settings.allowedUserIds.map(String).includes(String(B24.currentUser.id)));

  if (!allowed) {
    document.querySelector('header').style.display = 'none';
    document.getElementById('viewCalendar').style.display = 'none';
    document.getElementById('accessDeniedScreen').style.display = '';
    return;
  }

  initMiniCalendars();
  await refreshAll();
});
